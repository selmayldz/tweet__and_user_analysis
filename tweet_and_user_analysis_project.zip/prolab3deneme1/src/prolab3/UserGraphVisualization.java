
package prolab3;

import javax.swing.*;
import java.awt.*;

public class UserGraphVisualization extends JFrame {

    private UserGraph userGraph;
    private User user;

    public UserGraphVisualization(UserGraph userGraph, User user) {
        this.userGraph = userGraph;
        this.user = user;
        initUI();
    }

    private void initUI() {
        setTitle("User Graph Visualization");
        setSize(2000, 2000);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        UserGraphPanel graphPanel = new UserGraphPanel(userGraph, user);
        add(graphPanel);

        setLocationRelativeTo(null);
    }
 

   public static class UserGraphPanel extends JPanel {

        private UserGraph userGraph;
        private User user;

        public UserGraphPanel(UserGraph userGraph, User user) {
            this.userGraph = userGraph;
            this.user = user;
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            
            String username = user.getUsername();
            int centerX = getWidth() / 2;
            int centerY = getHeight() / 2;

            g.setColor(Color.RED);
            g.fillOval(centerX - 10, centerY - 10, 20, 20);

            for (String follower : userGraph.getFollowers(username)) {
                UserGraph.UserNode followerNode = userGraph.getNode(follower);

                int followerX = (int) (Math.random() * getWidth());
                int followerY = (int) (Math.random() * getHeight());

                g.setColor(Color.GREEN);
                g.fillOval(followerX - 10, followerY - 10, 20, 20);
                g.setColor(Color.BLACK);
                g.drawLine(centerX, centerY, followerX, followerY);
                g.drawString(follower, followerX - 5, followerY - 15);
            }

            for (String following : userGraph.getFollowing(username)) {
                UserGraph.UserNode followingNode = userGraph.getNode(following);

                int followingX = (int) (Math.random() * getWidth());
                int followingY = (int) (Math.random() * getHeight());

                g.setColor(Color.BLUE);
                g.fillOval(followingX - 10, followingY - 10, 20, 20);
                g.setColor(Color.BLACK);
                g.drawLine(centerX, centerY, followingX, followingY);
                g.drawString(following, followingX - 5, followingY - 15);
            }
        }
}}