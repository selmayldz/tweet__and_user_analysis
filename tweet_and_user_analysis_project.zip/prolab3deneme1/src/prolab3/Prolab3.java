package prolab3;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Scanner;
import javax.swing.SwingUtilities;

public class Prolab3 {

    public static void main(String[] args) {
        UserGraph userGraph = new UserGraph();
        String jsonFilePath = "C:\\Users\\Selma Yıldız\\OneDrive\\Belgeler\\twitter_data.json\\twitter_data.json";

        try {
            String jsonData = new String(Files.readAllBytes(Paths.get(jsonFilePath)));

            JSONArray jsonArray = (JSONArray) new JSONParser().parse(jsonData);

            CustomHashTable customHashTable = new CustomHashTable();
            for (Object obj : jsonArray) {

                JSONObject userJson = (JSONObject) obj;

                User user = new User(
                        (String) userJson.get("username"),
                        (String) userJson.get("name"),
                        ((Long) userJson.get("followers_count")).intValue(),
                        ((Long) userJson.get("following_count")).intValue(),
                        (String) userJson.get("language"),
                        (String) userJson.get("region"),
                        convertJSONArrayToList((JSONArray) userJson.get("tweets")),
                        convertJSONArrayToList((JSONArray) userJson.get("following")),
                        convertJSONArrayToList((JSONArray) userJson.get("followers"))
                );

                customHashTable.addUser(user);

            }

            System.out.println("Lütfen bir kullanıcı adı giriniz:");
            Scanner scanner = new Scanner(System.in);
            String kullaniciGiris = scanner.nextLine();
            String usernameToSearch = kullaniciGiris;
            User retrievedUser = customHashTable.getUser(usernameToSearch);
            for (String follower : retrievedUser.getFollowers()) {
                userGraph.addFollower(follower, retrievedUser.getUsername());
            }

            for (String following : retrievedUser.getFollowing()) {
                userGraph.addFollowing(retrievedUser.getUsername(), following);
            }

            if (retrievedUser != null) {
                MyList<String> tweets = retrievedUser.getTweets();
                System.out.println("Retrieved User: " + retrievedUser.getName() + "   Tweets: " + tweets);
            } else {
                System.out.println("User with username " + usernameToSearch + " not found.");
            }
            SwingUtilities.invokeLater(() -> {
                UserGraphVisualization ex = new UserGraphVisualization(userGraph, retrievedUser);

                ex.setVisible(true);
            });
            ZemberekProcessor zemberekProcessor = new ZemberekProcessor(customHashTable);

            customHashTable.processUserTweetsWithZemberek(zemberekProcessor);

            customHashTable.herKullanıcınınEnCokKullandigi10KelimeyiBul();

            customHashTable.ortakKelimeleriBul();
        } catch (IOException | ParseException e) {
            e.printStackTrace();
        }

    }

    private static MyList<String> convertJSONArrayToList(JSONArray jsonArray) {
        MyList<String> resultList = new MyList<>();
        for (Object obj : jsonArray) {
            resultList.add((String) obj);
        }
        return resultList;
    }
}
