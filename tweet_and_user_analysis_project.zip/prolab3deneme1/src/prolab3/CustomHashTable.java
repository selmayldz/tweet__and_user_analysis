package prolab3;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Comparator;
import java.util.Iterator;

public class CustomHashTable {

    private static final int INITIAL_CAPACITY = 300000;
    private MyLinkedList<User>[] table;
    private MyLinkedList<KelimeFrekans>[] kelimeFrekansTable;
    private int size;
    private MyList<KelimeFrekans> kullaniciKelimeFrekansListesi;
    private UserGraph userGraph;

    public CustomHashTable() {
        table = new MyLinkedList[INITIAL_CAPACITY];
        for (int i = 0; i < INITIAL_CAPACITY; i++) {
            table[i] = new MyLinkedList<>();
        }
        size = 0;
        kelimeFrekansTable = new MyLinkedList[INITIAL_CAPACITY];
        for (int i = 0; i < INITIAL_CAPACITY; i++) {
            kelimeFrekansTable[i] = new MyLinkedList<>();
        }
        this.userGraph = new UserGraph();
    }

    private int hash(String key) {
        int hash = 0;
        for (int i = 0; i < key.length(); i++) {
            hash = (hash + key.charAt(i)) % table.length;
        }
        return Math.abs(hash);
    }

    private int hashForKelimeFrekans(String kelime) {
        int hash = 0;
        for (int i = 0; i < kelime.length(); i++) {
            hash = (hash * 31 + kelime.charAt(i)) % kelimeFrekansTable.length;
        }
        return Math.abs(hash);
    }

    public void addUser(User user) {
        int index = hash(user.getUsername());
        table[index].add(user);
        size++;
    }

    public User getUser(String username) {
        int index = hash(username);
        for (User user : table[index]) {
            if (user.getUsername().equals(username)) {
                return user;
            }
        }
        return null;
    }

    public void processUserTweetsWithZemberek(ZemberekProcessor zemberekProcessor) {
        for (MyLinkedList<User> userList : table) {
            for (User user : userList) {
                zemberekProcessor.processUserTweets(user);
            }
        }
    }

    public void addKelime(String username, String kelime) {
        int index = hashForKelimeFrekans(username);
        if (kelimeFrekansTable[index] == null) {
            kelimeFrekansTable[index] = new MyLinkedList<>();
        }

        MyLinkedList<KelimeFrekans> kelimeFrekansList = kelimeFrekansTable[index];
        KelimeFrekans existingKelime = findKelime(kelimeFrekansList, kelime);

        if (existingKelime != null) {
            existingKelime.frekans++;
        } else {
            kelimeFrekansList.add(new KelimeFrekans(username, kelime, 1));
        }
    }

    private KelimeFrekans findKelime(MyLinkedList<KelimeFrekans> kelimeFrekansList, String kelime) {
        for (KelimeFrekans kelimeFrekans : kelimeFrekansList) {
            if (kelimeFrekans.kelime.equals(kelime)) {
                return kelimeFrekans;
            }
        }
        return null;
    }

    public Iterable<User> getAllUsers() {
        return () -> new Iterator<User>() {
            private int index = 0;

            @Override
            public boolean hasNext() {
                while (index < table.length && table[index] == null) {
                    index++;
                }
                return index < table.length && table[index] != null;
            }

            @Override
            public User next() {
                return table[index].iterator().next();
            }
        };
    }

    MyList<dilbolgetrend>[] bolgeTrendListeleri = new MyList[INITIAL_CAPACITY];

    public void herKullanıcınınEnCokKullandigi10KelimeyiBul() throws IOException {
        CustomHashTable customhashtable = new CustomHashTable();
        ZemberekProcessor zemb = new ZemberekProcessor(customhashtable);
        try (PrintWriter writer = new PrintWriter(new FileWriter("kullanici_ilgialani_raporu.txt"))) {
            for (MyLinkedList<User> kullaniciListesi : table) {
                if (kullaniciListesi != null) {
                    for (User kullanici : kullaniciListesi) {
                        String kullaniciAdi = kullanici.getUsername();
                        MyList<KelimeFrekans> kullaniciKelimeFrekansListesi = getKullaniciKelimeFrekansListesi(kullaniciAdi);
                        String bolge = kullanici.getRegion();

                        kullaniciKelimeFrekansListesi.sort(Comparator.comparingInt(KelimeFrekans::getFrekans).reversed().thenComparing(KelimeFrekans::getKelime));

                        System.out.println(kullaniciAdi + " için ilgi alanları:");
                        writer.println(kullaniciAdi + " için ilgi alanları:");
                        for (int i = 0; i < 10 && i < kullaniciKelimeFrekansListesi.size(); i++) {
                            KelimeFrekans kelimeFrekans = kullaniciKelimeFrekansListesi.get(i);

                            String kelimeKoku = kelimeFrekans.getKelime();

                            writer.println("İlgi alanı: " + kelimeFrekans.getKelime() + " Frekans: " + kelimeFrekans.getFrekans());

                            MyList<TweetBilgisi> ilgiAlaniIcerenTweetler = getIlgiAlaniniIcerenTweetler(kullanici, kelimeKoku);
                            System.out.println("İlgi alanı: " + kelimeFrekans.getKelime() + " Frekans: " + kelimeFrekans.getFrekans());
                            for (TweetBilgisi tweetbilgisi : ilgiAlaniIcerenTweetler) {
                                MyList<String> kelimeler = zemb.zemberekIleAyrıştır(tweetbilgisi.getTweet());

                                if (kelimeler.stream().anyMatch(kelime -> kelime.equalsIgnoreCase(kelimeKoku))) {
                                    System.out.println("    Tweet: " + tweetbilgisi.getTweet());
                                }
                            }
                            addTrendToBolgeList(bolge, kelimeFrekans.getKelime());
                        }
                        System.out.println();
                        writer.println();
                    }
                }
            }
            for (int i = 0; i < bolgeTrendListeleri.length; i++) {
                MyList<dilbolgetrend> bolgeTrendListesi = bolgeTrendListeleri[i];
                if (bolgeTrendListesi != null && !bolgeTrendListesi.isEmpty()) {
                    System.out.println(bolgeTrendListesi);
                }
            }
        }
    }

    public void addTrendToBolgeList(String bolge, String trend) {
        int index = hash(bolge);
        MyList<dilbolgetrend> bolgeTrendListesi = bolgeTrendListeleri[index];

        if (bolgeTrendListesi == null) {
            bolgeTrendListesi = new MyList<>();
            bolgeTrendListeleri[index] = bolgeTrendListesi;
        }

        addTrendToList(bolgeTrendListesi, bolge, trend);
    }

    private void addTrendToList(MyList<dilbolgetrend> trendListesi, String bolge, String trend) {
        if (trendListesi != null) {
            dilbolgetrend bolgeTrend = findBolgeTrend(bolge, trendListesi);
            bolgeTrend.addTrend(trend);
        }
    }

    private dilbolgetrend findBolgeTrend(String bolge, MyList<dilbolgetrend> bolgeTrendListesi) {
        for (dilbolgetrend bolgeTrend : bolgeTrendListesi) {
            if (bolgeTrend.getBolge().equals(bolge)) {
                return bolgeTrend;
            }
        }

        dilbolgetrend newBolgeTrend = new dilbolgetrend(bolge, new MyList<>());
        bolgeTrendListesi.add(newBolgeTrend);
        return newBolgeTrend;
    }

    private MyList<KelimeFrekans> getKullaniciKelimeFrekansListesi(String kullaniciAdi) {
        MyList<KelimeFrekans> kullaniciKelimeFrekansListesi = new MyList<>();

        int index = hashForKelimeFrekans(kullaniciAdi);
        if (kelimeFrekansTable[index] != null) {
            for (KelimeFrekans kelimeFrekans : kelimeFrekansTable[index]) {
                if (kelimeFrekans.getUsername().equals(kullaniciAdi)) {
                    kullaniciKelimeFrekansListesi.add(kelimeFrekans);
                }
            }
        }

        return kullaniciKelimeFrekansListesi;
    }

    public boolean user1TakipEdiyorUser2(String user1, String user2) {
        MyList<String> user1TakipEttigiKullanicilar = findUserByUsername(user1).getFollowing();

        return user1TakipEttigiKullanicilar.contains(user2);
    }

    public User findUserByUsername(String username) {
        for (MyLinkedList<User> kullaniciListesi : table) {
            if (kullaniciListesi != null) {
                for (User kullanici : kullaniciListesi) {
                    if (kullanici.getUsername().equals(username)) {
                        return kullanici;
                    }
                }
            }
        }
        return null;
    }

    public void ortakKelimeleriBul() {
        MyList<CommonWordUsage> commonWordUsages = new MyList<>();

        for (MyLinkedList<User> kullaniciListesi : table) {
            if (kullaniciListesi != null) {
                for (User kullanici : kullaniciListesi) {
                    String kullaniciAdi = kullanici.getUsername();
                    MyList<KelimeFrekans> kullaniciKelimeFrekansListesi = getKullaniciKelimeFrekansListesi(kullaniciAdi);

                    kullaniciKelimeFrekansListesi.sort(Comparator.comparingInt(KelimeFrekans::getFrekans).reversed().thenComparing(KelimeFrekans::getKelime));

                    for (int i = 0; i < Math.min(10, kullaniciKelimeFrekansListesi.size()); i++) {
                        String kelime = kullaniciKelimeFrekansListesi.get(i).getKelime();

                        boolean found = false;
                        for (CommonWordUsage commonWordUsage : commonWordUsages) {
                            if (commonWordUsage.getWord().equals(kelime)) {
                                commonWordUsage.addUser(kullaniciAdi);
                                found = true;
                                break;
                            }
                        }

                        if (!found) {
                            CommonWordUsage newCommonWordUsage = new CommonWordUsage(kelime);
                            newCommonWordUsage.addUser(kullaniciAdi);
                            commonWordUsages.add(newCommonWordUsage);
                        }
                    }
                }
            }
        }

        for (CommonWordUsage commonWordUsage : commonWordUsages) {
            if (commonWordUsage.getUserCount() > 1) {
                System.out.println("İlgi Alanı: " + commonWordUsage.getWord());
                System.out.println("İlgi alanına sahip kullanıcılar: " + commonWordUsage.getUsers());

                findAndPrintConnectedUsers(commonWordUsage.getUsers());
                System.out.println();
            }
        }
    }

    private void findAndPrintConnectedUsers(MyList<String> users) {
        MyList<String> connectedUsers = new MyList<>();

        for (String user1 : users) {
            for (String user2 : users) {
                if (!user1.equals(user2)) {
                    boolean isFollowing = user1TakipEdiyorUser2(user1, user2);
                    boolean isFollower = user1TakipEdiyorUser2(user2, user1);

                    if (isFollowing || isFollower) {
                        connectedUsers.add(user1 + " - " + user2);
                    }
                }
            }
        }

        for (String connectedUser : connectedUsers) {
            System.out.println("Connected users: " + connectedUser);
        }
    }

    public class CommonWordUsage {

        private String word;
        private MyList<String> users;

        public CommonWordUsage(String word) {
            this.word = word;
            this.users = new MyList<>();
        }

        public String getWord() {
            return word;
        }

        public void addUser(String user) {
            users.add(user);
        }

        public int getUserCount() {
            return users.size();
        }

        public MyList<String> getUsers() {
            return users;
        }
    }

    private MyList<TweetBilgisi> getIlgiAlaniniIcerenTweetler(User kullanici, String ilgiAlani) {
        MyList<TweetBilgisi> ilgiAlaniniIcerenTweetler = new MyList<>();

        String kucukHarfliIlgiAlani = ilgiAlani.toLowerCase();

        for (String tweet : kullanici.getTweets()) {
            String kucukHarfliTweet = tweet.toLowerCase();

            if (kucukHarfliTweet.contains(kucukHarfliIlgiAlani)) {
                ilgiAlaniniIcerenTweetler.add(new TweetBilgisi(kullanici.getUsername(), tweet));
            }
        }

        return ilgiAlaniniIcerenTweetler;
    }

    private static class TweetBilgisi {

        private String kullaniciAdi;
        private String tweet;

        public TweetBilgisi(String kullaniciAdi, String tweet) {
            this.kullaniciAdi = kullaniciAdi;
            this.tweet = tweet;
        }

        public String getKullaniciAdi() {
            return kullaniciAdi;
        }

        public String getTweet() {
            return tweet;
        }
    }

    class dilbolgetrend {

        String bolge;
        MyList<String> trendler;

        public dilbolgetrend(String bolge, MyList<String> trendler) {
            this.bolge = bolge;
            this.trendler = trendler;
        }

        public String getBolge() {
            return bolge;
        }

        public MyList<String> getTrendler() {
            return trendler;
        }

        public void addTrend(String trend) {
            trendler.add(trend);
        }

        @Override
        public String toString() {
            return "Bölge " + bolge + " için trendler: " + trendler;
        }
    }

    class KelimeFrekans {

        String username;
        String kelime;
        int frekans;

        public KelimeFrekans(String username, String kelime, int frekans) {
            this.username = username;
            this.kelime = kelime;
            this.frekans = frekans;
        }

        public String getUsername() {
            return username;
        }

        public String getKelime() {
            return kelime;
        }

        public int getFrekans() {
            return frekans;
        }
    }
}