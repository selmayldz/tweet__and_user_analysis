
package prolab3;

public class UserGraph {
    private UserNode[] nodes;
    private int size;

    public UserGraph() {
        this.nodes = new UserNode[10];
        this.size = 0;
    }

public void addFollower(String follower, String following) {
    UserNode followingNode = getNode(following);
    UserNode followerNode = getNode(follower);

    if (!isFollower(followingNode, followerNode)) {
        followerNode.next = followingNode.followers;
        followingNode.followers = followerNode;

        System.out.println("Added follower: " + follower + " for user: " + following);
    }
}

public void addFollowing(String follower, String following) {
    UserNode followerNode = getNode(follower);
    UserNode followingNode = getNode(following);

    if (!isFollowing(followerNode, followingNode)) {
        followingNode.next = followerNode.following;
        followerNode.following = followingNode;

        System.out.println("Added following: " + follower + " for user: " + following);
    }
}

public boolean isFollower(UserNode followingNode, UserNode followerNode) {
    UserNode current = followingNode.followers;

    while (current != null) {
        if (current.username.equals(followerNode.username)) {
            return true;
        }
        current = current.next;
    }

    return false;
}

public boolean isFollowing(UserNode followerNode, UserNode followingNode) {
    UserNode current = followerNode.following;

    while (current != null) {
        if (current.username.equals(followingNode.username)) {
            return true;
        }
        current = current.next;
    }

    return false;
}

    public UserNode[] getNodes() {
        UserNode[] result = new UserNode[size];
        System.arraycopy(nodes, 0, result, 0, size);
        return result;
    }

    public UserNode getNode(String username) {
        for (int i = 0; i < size; i++) {
            if (nodes[i].username.equals(username)) {
                return nodes[i];
            }
        }

        UserNode newNode = new UserNode(username);
        newNode.next = null;

        if (size == nodes.length) {
            UserNode[] newNodes = new UserNode[size * 2];
            System.arraycopy(nodes, 0, newNodes, 0, size);
            nodes = newNodes;
        }

        nodes[size++] = newNode;
        return newNode;
    }

    public String[] getFollowers(String username) {
        UserNode userNode = getNode(username);
        String[] followersArray = new String[size(userNode.followers)];

        UserNode current = userNode.followers;
        int index = 0;
        while (current != null) {
            followersArray[index++] = current.username;
            current = current.next;
        }

        return followersArray;
    }
public String[] getFollowing(String username) {
    UserNode userNode = getNode(username);
    String[] followingArray = new String[size(userNode.following)];

    UserNode current = userNode.following;
    int index = 0;
    while (current != null) {
        followingArray[index++] = current.username;
        current = current.next;
    }

    return followingArray;
}
    public int size(UserNode node) {
        int count = 0;
        UserNode current = node;
        while (current != null) {
            count++;
            current = current.next;
        }
        return count;
    }

    public static class UserNode {
        public final String username;
        private UserNode followers;
        private UserNode following;
        private UserNode next;

        public UserNode(String username) {
            this.username = username;
            this.followers = null;
            this.following=null;
            this.next = null;
        }
    }
    
    
}