package prolab3;

import zemberek.morphology.TurkishMorphology;
import zemberek.morphology.analysis.SingleAnalysis;
import zemberek.morphology.analysis.WordAnalysis;
import zemberek.tokenization.TurkishTokenizer;
import zemberek.tokenization.Token;
import java.io.IOException;
import java.util.List;
import java.util.Arrays;
import java.util.ArrayList;


public class ZemberekProcessor {

    private TurkishTokenizer tokenizer;
    private TurkishMorphology morphology;
    private CustomHashTable kelimeFrekansTable;


    public ZemberekProcessor(CustomHashTable kelimeFrekansTable) throws IOException {
        this.tokenizer = TurkishTokenizer.builder().ignoreTypes().build();
        this.kelimeFrekansTable = kelimeFrekansTable;
        this.morphology = TurkishMorphology.createWithDefaults();
    }

    public void processUserTweets(User user){
        MyList<String> tweets = user.getTweets();

        for (String tweet : tweets) {
            MyList<String> kelimeler = zemberekIleAyrıştır(tweet);

            for (String kelime : kelimeler) {
                kelimeFrekansTable.addKelime(user.getUsername(), kelime);
            }
        }
    }
    ArrayList<String> engellenenKelimeler = new ArrayList<>(Arrays.asList(
    "bul", "ara", "et", "eylemek", "olmak", "aa", "acaba", "ait", "altı", "a", "al", "altmış", "ama", "amma",
    "anca", "ancağ", "ancak", "artık", "asla", "aslında", "az", "b", "bana", "bari", "başkası", "bazen", "başla",
    "bazı", "bazıları", "bazısı", "be", "belki", "ben", "bende", "benden", "beni", "benim", "beş", "bide",
    "bile", "bin", "bir", "birazı", "birçoğ", "birçoğu", "birçok", "birçokları", "biri", "birisi", "birkaç",
    "birkaçı", "birkez", "birşey", "birşeyi", "biz", "bizden", "bize", "bizi", "bizim", "böyle", "böylece",
    "değişik", "son", "gel", "ayn", "yer", "bu", "buna", "bunda", "bundan", "bunu", "bunun", "burada",
    "bütün", "c", "ç", "çoğu", "çoğuna", "çoğunu", "çok", "çünkü", "d", "da", "daha", "dahi", "dandini",
    "de", "defa", "değ", "değil", "değin", "dek", "demek", "diğer", "diğeri", "diğerleri", "diye", "dk",
    "dha", "doğrusu", "doksan", "dokuz", "dolayı", "dört", "e", "eğer", "eh", "elbette", "elli", "en",
    "etkili", "f", "fakat", "fakad", "falan", "falanca", "felan", "filan", "filanca", "g", "ğ", "gene",
    "gereğ", "gibi", "göre", "görece", "h", "hakeza", "hakkında", "hâlâ", "halbuki", "hangi", "hangisi",
    "hani", "hasebiyle", "hatime", "hatta", "hele", "hem", "henüz", "hep", "hepsi", "hepsine", "hepsini",
    "her", "her biri", "herkes", "herkese", "herkesi", "hiç", "hiç kimse", "hiçbiri", "hiçbirine", "hiçbirini",
    "hoş", "i", "ı", "ın", "için", "içinde", "içre", "iki", "ila", "ile", "imdi", "indinde", "intağ", "intak",
    "ise", "işte", "ister", "j", "k", "kaç", "kaçı", "kadar", "kah", "karşın", "katrilyon", "kelli", "kendi",
    "kendine", "kendini", "keşke", "keşki", "kez", "keza", "kezaliğ", "kezalik", "ki", "kim", "kimden",
    "kime", "kimi", "kimin", "kimisi", "kimse", "kırk", "kullan", "l", "67", "lakin", "m", "madem", "mademki", "mamafih",
    "meğer", "meğerki", "meğerse", "mi", "mı", "milyar", "milyon", "mu", "mü", "n", "nasıl", "nde", "ne", "ne kadar",
    "ne zaman", "neden", "nedense", "nedir", "nerde", "nere", "nerede", "nereden", "nereli", "neresi", "nereye",
    "nesi", "neye", "neyi", "neyse", "niçin", "ni", "nı", "nin", "nın", "nitekim", "niye", "o", "ö", "öbürkü",
    "öbürü", "on", "ön", "ona", "önce", "onda", "ondan", "onlar", "onlara", "onlardan", "onlari", "onların",
    "onu", "onun", "orada", "ötekisi", "ötürü", "otuz", "öyle", "oysa", "oysaki", "p", "pad", "pat", "peki",
    "r", "rağmen", "s", "ş", "sakın", "sana", "sanki", "şayet", "sekiz", "seksen", "sen", "senden", "seni",
    "senin", "son", "sonra", "68", "şöyle", "şu", "şuna", "şunda", "şundan", "şunu", "şunun", "t", "ta", "tabi",
    "tamam", "tl", "trilyon", "tüm", "tümü", "u", "ü", "üç", "üsd", "üst", "uyarınca", "üzere", "v", "var", "ve",
    "velev", "velhasıl", "velhasılıkelam", "vesselam", "veya", "veyahud", "veyahut", "y", "ya", "ya da", "yani", "yap", 
    "yazığ", "yazık", "yedi", "yekdiğeri", "yerine", "yetmiş", "yine", "yirmi", "yoksa", "yukarda", "yukardan",
    "yukarıda", "yukarıdan", "yüz", "z", "zaten", "zinhar", "zira", "tür", "cins", "ad", "iyi", "kötü", "çeşit",
    "ol", "tut", "değer", "ad", "çeşit", "örnek", ".", " ", "olarak", "\"", "tarafından", "ver", "ilk","oldu", 
    "büyük", "ayrıca", "ed", "bulun", "[", "]", "!", ":", ";"
)); 
    public MyList<String> zemberekIleAyrıştır(String tweet) {
        List<Token> tokens = tokenizer.tokenize(tweet);
        MyList<String> result = new MyList<>();

        for (Token token : tokens) {
            String kelime = token.getText();
            String kelimeKoku = getRootForm(kelime);

            if (!engellenenKelimeler.contains(kelimeKoku.toLowerCase())) {
                result.add(kelimeKoku);
            }
        }

        return result;
    }
    public String getRootForm(String word) {
    WordAnalysis analysis = morphology.analyze(word);
    List<SingleAnalysis> analysisList = analysis.getAnalysisResults();

    if (!analysisList.isEmpty()) {
        return analysisList.get(0).getStems().get(0).toLowerCase();
    }
    return word.toLowerCase();
}

}
