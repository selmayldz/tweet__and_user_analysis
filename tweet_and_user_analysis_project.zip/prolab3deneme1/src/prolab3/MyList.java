
package prolab3;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Iterator;
import java.util.Spliterator;
import java.util.Spliterators;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

public class MyList<T> implements Iterable<T>{
    private static final int INITIAL_CAPACITY = 10;
    private Object[] elements;
    private int size;

    public MyList() {
        elements = new Object[INITIAL_CAPACITY];
        size = 0;
    }

    public void add(T element) {
        ensureCapacity(size + 1);
        elements[size++] = element;
    }

    @SuppressWarnings("unchecked")
    public T get(int index) {
        if (index < 0 || index >= size) {
            throw new IndexOutOfBoundsException("Index: " + index + ", Size: " + size);
        }
        return (T) elements[index];
    }

    public MyList<T> subList(int fromIndex, int toIndex) {
        if (fromIndex < 0 || fromIndex >= size || toIndex < 0 || toIndex > size || fromIndex > toIndex) {
            throw new IndexOutOfBoundsException();
        }
        MyList<T> subList = new MyList<>();

        for (int i = fromIndex; i < toIndex; i++) {
            @SuppressWarnings("unchecked")
            T element = (T) elements[i];
            subList.add(element);
        }

        return subList;
    }
    
    private void ensureCapacity(int minCapacity) {
        if (minCapacity > elements.length) {
            int newCapacity = Math.max(elements.length * 2, minCapacity);
            elements = Arrays.copyOf(elements, newCapacity);
        }
    }
    
    public boolean isEmpty() {
        return size == 0;
    }


    public int size() {
        return size;
    }
    @Override
    public String toString() {
        StringBuilder result = new StringBuilder();
        result.append("[");
        for (int i = 0; i < size; i++) {
            result.append(elements[i]);
            if (i < size - 1) {
                result.append(", ");
            }
        }
        result.append("]");
        return result.toString();
    }
     @Override
    public Iterator<T> iterator() {
        return new MyListIterator();
    }
    public boolean contains(T element) {
        for (int i = 0; i < size; i++) {
            if (elements[i].equals(element)) {
                return true;
            }
        }
        return false;
    }
    
    public Stream<T> stream() {
        Spliterator<T> spliterator = Spliterators.spliteratorUnknownSize(iterator(), Spliterator.ORDERED);
        return StreamSupport.stream(spliterator, false);
    }

    public void addAll(MyList<T> otherList) {
        ensureCapacity(size + otherList.size);

        System.arraycopy(otherList.elements, 0, elements, size, otherList.size);
        size += otherList.size;
    }
  
     public T[] toArray(T[] array) {
        if (array.length < size) {
            array = Arrays.copyOf(array, size);
        }
        System.arraycopy(elements, 0, array, 0, size);
        return array;
    }

   public void sort(Comparator<? super T> comparator) {
    Arrays.sort((T[]) elements, 0, size, comparator);
}

    private class MyListIterator implements Iterator<T> {
        private int currentIndex = 0;

        @Override
        public boolean hasNext() {
            return currentIndex < size;
        }

        @Override
        public T next() {
            if (!hasNext()) {
                throw new IndexOutOfBoundsException("No more elements");
            }
            return get(currentIndex++);
        }
    }
}
