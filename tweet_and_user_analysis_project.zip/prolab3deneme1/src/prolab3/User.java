
package prolab3;

public class User {
    private final String username;
    private final String name;
    private final int followersCount;
    private final int followingCount;
    private final String language;
    private final String region;
    private final MyList<String> tweets;
    private final MyList<String> following;
    private final MyList<String> followers;
    

    public User(String username, String name, int followersCount, int followingCount, String language, String region, MyList<String> tweets,MyList<String> following,MyList<String> followers) {
        this.username = username;
        this.name = name;
        this.followersCount = followersCount;
        this.followingCount = followingCount;
        this.language = language;
        this.region = region;
        this.tweets = tweets;
        this.followers = followers;
        this.following = following;
    }

    public String getUsername() {
        return username;
    }

    public String getName() {
        return name;
    }
    public String getRegion(){
        return region;
    }
    public String getLanguage(){
        return language;
    }
    public int getFollowersCount(){
        return followersCount;
    }
    public int getFollowingCount(){
        return followingCount;
    }
    public MyList<String> getTweets(){
        return tweets;
    }
    public MyList<String> getFollowers(){
        return followers;
    }
    public MyList<String> getFollowing(){
        return following;
    }
}
